package com.cgaines.android.atroxx;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

//class used for accessing connection details
public class ServerDetails extends AsyncTask<String, Void, Void> {
    private String _IP;
    private int port;
    Socket mySocket;
    InetAddress serverAddr;
    private PrintWriter out;
    private BufferedReader in;
    ServerDetails(){
        //default constructor
    }

    @Override
    protected Void doInBackground(String... strings) {
        String myMsg = strings[0];
        try {
            out.println(myMsg);
            if(myMsg.contains("move")){//Zaku can move everyother move, auto-skips
                out.println("noop");
            }
        } catch (Exception e) {
            e.printStackTrace();
            myMsg = "Invalid Command.";
        }
        return null;
    }

    //constructor is fed upon connection to create a reference in main frag
    ServerDetails(PrintWriter out, BufferedReader in) {
        this.out = out;
        this.in = in;
    }
}
