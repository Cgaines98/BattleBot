package com.cgaines.android.atroxx;

public class Bot {
    private String myStatus;

    private int myTeam;
    private int positionX, positionY, myHP, ATK, scanDist, myMoveCount, bulletPow,
            bulletRange, rateOfFire, myShotCount, shotAngle;
    // this bot can move every other message
    // 2 - 1 = 1
    private int _moveRate;
    private int red, green, blue;

    // default constructor
    // defaults on server for HP, ATK, and Scan are 1.
    Bot() {
        myTeam = 1;
        myStatus = "new";
        positionX = 0;
        positionY = 0;
        myHP = 1;
        ATK = 2;
        // scan distance is multiplied by a factor of 100
        scanDist = 2;
        // this bot can move every other message
        // 2 - 1 = 1
        _moveRate = myHP - 1;
        // if bulletPow is 2, then this bot can move again after 2 messages, and shoot
        // again after 20 messages (see rate of fire)
        // myMoveCount = myMoveCount - bulletPow;
        myMoveCount = 0;
        // bullets are gained through moving, scanning, and pickups
        myShotCount = 0;
        bulletPow = 0;
        // bullet range is the diagonal of the arena divided by bullet power
        // a diagonal is just a hypotenuse so...
        // a^2 + b^2 = c^2, where c is the hypotenuse.
        //(bullet range = c / bulletPow)
        bulletRange = 0;
        //bulletRange = (int) (sqrt(
        //                (pow(widthArena, 2) + pow(heightArena, 2))
        //                      )/ bulletPow);
        //more power translates to slower firing
        //rateOfFire = bulletPow * 10;
        rateOfFire = 0;
        //shoot straight ahead by default.
        shotAngle = 0;
    }

    // mutator methods
    public void updatePosition(int x, int y) {
        positionX = x;
        positionY = y;
    }
    public String getShotAngle(){
        return String.valueOf(shotAngle);
    }
    // decremented when shooting
    public void updateMoveCount(int currentCount) {
        myMoveCount = currentCount;
    }

    public void updateShotCount(int currentShotCount) {
        myShotCount = currentShotCount;
    }

    public void updateHP(int currentHP) {
        myHP = currentHP;
    }

    // for server message during setup
    public String BotInfoString() {
        String hitPoints = String.valueOf(myHP);
        String attack = String.valueOf(ATK);
        String scanDistance = String.valueOf(scanDist);///100);

        return "me" + " " + hitPoints + " " + attack + " " + scanDistance;
    }

    // uses information about the bot that
    // is returned by the server after first
    // client-side message
    public void updateBot(String servMsg) {
        String[] splitMsg = parse(servMsg);
        //myName = splitMsg[0];
        myHP = Integer.parseInt(splitMsg[1]);
        _moveRate = Integer.parseInt(splitMsg[2]);
        scanDist = Integer.parseInt(splitMsg[3]);
        bulletPow = Integer.parseInt(splitMsg[4]);
        rateOfFire = Integer.parseInt(splitMsg[5]);
        bulletRange = Integer.parseInt(splitMsg[6]);
        red = Integer.parseInt(splitMsg[7]);
        green = Integer.parseInt(splitMsg[8]);
        blue = Integer.parseInt(splitMsg[9]);
    }

    //called whenever there is a status update from the server
    public void updateStatus(String servMsg) {
        String[] splitMsg = parse(servMsg);
        updatePosition(Integer.parseInt(splitMsg[1]),
                Integer.parseInt(splitMsg[2]));
        updateMoveCount(Integer.parseInt(splitMsg[3]));
        updateShotCount(Integer.parseInt(splitMsg[4]));
        updateHP(Integer.parseInt(splitMsg[5]));
    }
    // uses arc tangent to calculate the angle from
    // zaku to a target, doesn't work.
    public void updateTarget(String servMsg){
        String[] splitMsg = parse(servMsg);
        int x, y, x1, x2, y1, y2;
        double radians, degrees;
        x1 = positionX;
        y1 = positionY;
        x2 = Integer.parseInt(splitMsg[3]);
        y2 = Integer.parseInt(splitMsg[4]);

        x = x1 - x2;
        y = y1 - y2;

        radians = Math.atan2(x, y);
        degrees = Math.floor( (radians * 180)/ Math.PI);
        shotAngle = (int) degrees;
    }
    // takes a String and returns a String array
    // where elements are delineated by white space
    // (used for attaining values from message)
    public String[] parse(String servMsg) {
        return servMsg.split(" ");
    }
}
