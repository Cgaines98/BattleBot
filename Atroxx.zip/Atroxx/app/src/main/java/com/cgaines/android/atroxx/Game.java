package com.cgaines.android.atroxx;

public class Game {
    private int _PID;
    private int _arenaWidth;
    private int _arenaHeight;
    private int _numBots;
    private int _team;
    private boolean _gameOver;

    //default constructor
    Game() {
        _PID = 0;
        _arenaWidth = 0;
        _arenaHeight = 0;
        _numBots = 0;
        _team = 0;
        _gameOver = false;
    }

    //mutator method
    public void set_gameOver(boolean b) {
        _gameOver = b;
    }

    //accessor methods
    public int get_PID() {
        return _PID;
    }

    public boolean is_gameOver() {
        return _gameOver;
    }

    //make game
    public void setUp(@org.jetbrains.annotations.NotNull String servMsg) {
        String[] splitMsg = servMsg.split(" ");
        _PID = Integer.parseInt(splitMsg[1]);
        _arenaWidth = Integer.parseInt(splitMsg[2]);
        _arenaHeight = Integer.parseInt(splitMsg[3]);
        _numBots = Integer.parseInt(splitMsg[4]);
        _team = Integer.parseInt(splitMsg[5]);

    }


}
