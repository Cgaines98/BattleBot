package com.cgaines.android.atroxx;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import androidx.fragment.app.Fragment;

import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.InetAddress;
import java.net.Socket;

import com.cgaines.android.atroxx.R.*;

public class MainFragment extends Fragment implements Button.OnClickListener {
    PrintWriter out;
    BufferedReader in;
    ServerDetails sd;
    Thread myNet;
    Bot zaku;
    Game battleBots;
    ImageView dpad;
    ImageButton shoot;
    Button makeconn, makeNewGame, skip, scan;
    //buttons to overlay dpad.png
    Button dpad_left, dpad_right, dpad_down, dpad_up;
    EditText hostname, port;
    TextView output;

    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView = inflater.inflate(layout.fragment_main, container, false);
        battleBots = new Game();
        zaku = new Bot();

        hostname = myView.findViewById(id.hostname);
        hostname.setText("10.0.2.2");
        port = myView.findViewById(id.port);
        port.setText("3012");
        output = myView.findViewById(id.output);
        output.append("\n");
        output.setMovementMethod(new ScrollingMovementMethod());

        makeconn = myView.findViewById(id.makeconn);
        makeconn.setOnClickListener(this);
        skip = myView.findViewById(id.skip_button);
        skip.setOnClickListener(this);
        scan = myView.findViewById(id.scan_button);
        scan.setOnClickListener(this);
        shoot = myView.findViewById(id.shoot);
        shoot.setOnClickListener(this);
        makeNewGame = myView.findViewById(id.newgame_button);
        makeNewGame.setOnClickListener(this);
        //elements for the directional pad
        dpad = myView.findViewById(id.dpad);
        dpad_left = myView.findViewById(id.d_left);
        dpad_left.setOnClickListener(this);
        dpad_right = myView.findViewById(id.d_right);
        dpad_right.setOnClickListener(this);
        dpad_up = myView.findViewById(id.d_up);
        dpad_up.setOnClickListener(this);
        dpad_down = myView.findViewById(id.d_down);
        dpad_down.setOnClickListener(this);

        return myView;
    }
    // other than makeconn, each button makes a call to
    // the serverbroker's async task (myTask) to output the appropriate
    // message/command to the server
    @Override
    public void onClick(View v) {
        mkmsg("Processing request...\n");
        //create our local server reference
        sd = new ServerDetails(out, in);
        switch (v.getId()) {
            case id.makeconn:
                doNetwork setup = new doNetwork();
                myNet = new Thread(setup);
                myNet.start();
                //freezes network controls while connected to server
                if(sd != null) lockInConnection();
                break;
            case id.shoot:
                mkmsg("fire straight ahead\n\n");
                sd.execute("fire " + zaku.getShotAngle());
                break;
            case id.d_left:
                mkmsg("move left\n\n");
                sd.execute("move -100 0");
                break;
            case id.d_right:
                mkmsg("move right\n\n");
                sd.execute("move 100 0");
                break;
            case id.d_up:
                mkmsg("move up\n\n");
                sd.execute("move 0 -100");
                break;
            case id.d_down:
                mkmsg("move down\n\n");
                sd.execute("move 0 100");
                break;
            case id.skip_button:
                mkmsg("skip turn\n\n");
                sd.execute("noop");
                break;
            case id.scan_button:
                mkmsg("scan area\n\n");
                sd.execute("scan");
                break;
            case id.newgame_button:
                startNewGame();
                break;

        }
    }

    // unlocks connection fields/controller
    // new up on game and bot
    public void startNewGame(){
        //new up a game and bot
        //todo force connection to end gracefully
        sd = new ServerDetails();
        battleBots = new Game();
        zaku = new Bot();
        //re-enable connection fields
        makeconn.setEnabled(true);
        hostname.setEnabled(true);
        port.setEnabled(true);
        output.setText("Game Reset\n");
    }
    // used for freezing the connection control and text fields
    // after a successful connection
    public void lockInConnection(){
        makeconn.setEnabled(false);
        hostname.setEnabled(false);
        port.setEnabled(false);
        output.setText("");
    }

    private final Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            output.append(msg.getData().getString("msg"));
            return true;
        }
    });

    public void mkmsg(String str) {
        //handler junk, because thread can't update screen!
        Message msg = new Message();
        Bundle b = new Bundle();
        b.putString("msg", str);
        msg.setData(b);
        handler.sendMessage(msg);
    }
    /*
     * this code does most of the setup work in a thread, so that it doesn't lock up the activity_main (UI) thread
     * It calls mkmsg (which calls the handler to update the screen)
     */
    class doNetwork implements Runnable {
        public void run() {
            int p = Integer.parseInt(port.getText().toString());
            String h = hostname.getText().toString();
            mkmsg("Host is " + h + "\n");
            mkmsg(" Port is " + p + "\n");
            String myMsg = zaku.BotInfoString(); //info string = 'me 1 2 2'

            try {
                InetAddress serverAddr = InetAddress.getByName(h);
                mkmsg("Attempting Connection..." + h + "\n\n");
                Socket socket = new Socket(serverAddr, p);
                //made connection, setup the read (in) and write (out)
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // setup
                String servMsg = in.readLine();
                battleBots.setUp(servMsg);
                mkmsg("Constructed an arena with PID: " + battleBots.get_PID() + "\n");
                // send bot info
                out.println(myMsg);
                mkmsg("Sending bot info to server: " + myMsg + "\n\n");
                myMsg = zaku.BotInfoString();
                out.println(myMsg);

                servMsg = in.readLine();
                //check for resend request
                if (servMsg.contains("setup error")) {
                    mkmsg("Server reported a " + servMsg + " for " + myMsg + ".\n");
                    myMsg = zaku.BotInfoString(); //reup info
                    out.println(myMsg);
                    mkmsg("Resending bot info...\n\n");
                }

                // update with new attributes from server
                if (servMsg.startsWith("me")) {
                    mkmsg("Attributes received, updating bot...\n\n");
                    zaku.updateBot(servMsg);
                }

                // while the game is still going
                // evaluate the keyword in the message (ie "status")
                // and act accordingly
                try {
                    while (!battleBots.is_gameOver()) {
                        // receiving msg from the server
                        servMsg = in.readLine();

                        // update the bot with status msg
                        if (servMsg.startsWith("status")) {
                            zaku.updateStatus(servMsg);
                            mkmsg(servMsg + "\n");
                            mkmsg("Bot was updated \n\n");
                            mkmsg("Make your move!\n\n");
                        }
                        if(servMsg.startsWith("scan")){
                            mkmsg(servMsg + "\n");
                            // zaku.updateTarget(servMsg);
                        }
                        // if we die or win, the game is over.
                        // and the server cuts the connection
                        // info will tell us when this happens
                        if (servMsg.startsWith("info")) {
                            if (servMsg.contains("dead") |
                                    servMsg.contains("gameover")) {
                                mkmsg("GAME OVER");
                                battleBots.set_gameOver(true);
                            }
                            if(servMsg.contains("Info hit")){
                                String statusMsg = in.readLine();
                                zaku.updateStatus(statusMsg);
                            }
                            if(servMsg.contains("BadCmd")){
                                mkmsg("Server says: " + servMsg + "\n");
                            }
                            else mkmsg(servMsg + "\n");
                        }
                    }
                } catch (Exception e) {
                    mkmsg("Error happened sending/receiving\n");

                } finally {
                    in.close();
                    out.close();
                    socket.close();
                    mkmsg("Closing connection");
                }

            } catch (Exception e) {
                mkmsg("Unable to connect...\n");
            }
        }
    }
}
